# Online Casino (Game Money Version)

This project contains 5 casino games using game money:
- Crash
- Mines
- Plinko
- Blackjack
- Baccarat

## How to run
```bash
npm install
npm start
```